TaPTaP Game Engine

This is a JSON-driven educational game engine.

Run Instructions:
1. Download repository
2. Open index.html in browser

JSON Configuration:
Game rules, levels, and scoring are defined in game-config.json.

Engine/Data Separation:
engine.js handles logic
game-config.json stores game data