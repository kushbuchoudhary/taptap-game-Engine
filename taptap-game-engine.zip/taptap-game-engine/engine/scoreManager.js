export function updateScore(score){

    document.getElementById("score").innerText = score;
}