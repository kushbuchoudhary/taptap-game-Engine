export function renderLevel(level, callback){

    const q = document.getElementById("question");
    const optionsDiv = document.getElementById("options");

    q.innerText = level.question;

    optionsDiv.innerHTML = "";

    level.options.forEach(option => {

        const btn = document.createElement("button");

        btn.innerText = option;

        btn.onclick = () => callback(option);

        optionsDiv.appendChild(btn);
    });
}