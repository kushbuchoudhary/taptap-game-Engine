import { loadGameConfig } from "./loader.js";
import { renderLevel } from "./renderer.js";
import { updateScore } from "./scoreManager.js";

let config;
let levelIndex = 0;
let score = 0;

export async function startGame(){

    config = await loadGameConfig();

    document.getElementById("title").innerText = config.gameTitle;

    score = config.settings.startingScore;

    loadLevel();
}

function loadLevel(){

    const level = config.levels[levelIndex];

    renderLevel(level, handleAnswer);
}

function handleAnswer(selected){

    const correct = config.levels[levelIndex].answer;

    if(selected === correct){

        score += config.settings.pointsPerCorrect;

        alert("Correct!");
    }
    else{
        alert("Wrong!");
    }

    updateScore(score);

    levelIndex++;

    if(levelIndex < config.levels.length){
        loadLevel();
    }
    else{
        alert("Game Completed!");
    }
}