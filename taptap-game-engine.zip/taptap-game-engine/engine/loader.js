export async function loadGameConfig() {

    const response = await fetch("./data/gameConfig.json");
    const config = await response.json();

    return config;
}